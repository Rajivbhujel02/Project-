package com.shalabydev.sports_zone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
