package com.shalabydev.sports_zone_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
