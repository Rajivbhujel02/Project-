import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../models/tems_model/tems_model.dart';

class TeamsScorer {
  static const String _apiKey =
      '6209eb3703ba9abe52d336d8b5a27709c0f14d8ee94c0142aa360068996429be';
  static const String _baseUrl = 'https://apiv2.allsportsapi.com/football/';

  Future<TemsModel?> getTeams(String search, int id, String choose) async {
    try {
      http.Response response;

      if (search != '') {
        response = await http.get(Uri.parse(
            "$_baseUrl+ $choose+ ?&met=Teams&APIkey=$_apiKey&leagueId=$id&teamName=$search"));
      } else {
        response = await http.get(
            Uri.parse("$_baseUrl?&met=Teams&APIkey=$_apiKey&leagueId=$id"));
      }
      Map<String, dynamic> decodedresponse = json.decode(response.body);
      if (response.statusCode == 200) {
        TemsModel data = TemsModel.fromJson(decodedresponse);
        return data;
      } else {
        return null;
      }
    } catch (error) {
      return null;
    }
  }
}
