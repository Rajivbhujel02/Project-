import 'dart:convert';
import 'package:http/http.dart' as http;

// ignore: unused_import

import 'package:sports_zone/data/models/leagues_model/legues_model.dart';

class LeaguesModelsRepo {
  static const String _apiKey =
      '6209eb3703ba9abe52d336d8b5a27709c0f14d8ee94c0142aa360068996429be';
  static const String _baseUrl = 'https://apiv2.allsportsapi.com/football/';
  Future<Zsc?> getLeaguesModels(int countryId) async {
    try {
      var response =
          await http.get(Uri.parse("$_baseUrl?met=Leagues&APIkey=$_apiKey"));

      Map<String, dynamic> deCodedResponse = json.decode(response.body);
      if (response.statusCode == 200) {
        Zsc data = Zsc.fromJson(deCodedResponse);
        return data;
      } else {
        return null;
      }
    } catch (e) {
      return null;
    }
  }
}
