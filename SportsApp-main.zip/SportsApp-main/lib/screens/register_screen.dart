import 'package:flutter/material.dart';
import 'package:sports_zone/components/custombutton.dart';
import 'package:sports_zone/screens/auth_service.dart';

import 'package:sports_zone/components/textfield.dart';
import 'package:sports_zone/screens/login_screen.dart';

class RegisterPage extends StatelessWidget {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  static const String imageURL =
      "https://as1.ftcdn.net/v2/jpg/02/78/42/76/1000_F_278427683_zeS9ihPAO61QhHqdU1fOaPk2UClfgPcW.jpg";
  RegisterPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(231, 255, 255, 255),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Form(
              key: formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text(
                    'Register',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 40),
                  CustomTextFromField(
                    label: 'username',
                    controller: nameController,
                  ),
                  const SizedBox(height: 20),
                  CustomTextFromField(
                    label: 'email',
                    controller: emailController,
                  ),
                  const SizedBox(height: 20),
                  CustomTextFromField(
                    label: 'password',
                    controller: passwordController,
                    isPassword: true,
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: CustomTextFromField(
                          label: 'phone',
                          controller: phoneController,
                        ),
                      ),
                      const SizedBox(width: 20),
                      Expanded(
                        child: CustomTextFromField(
                          label: 'address',
                          controller: addressController,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  CustomButton(
                    text: "Register",
                    onPressed: () async {
                      final message = await AuthService().registration(
                        email: emailController.text,
                        password: passwordController.text,
                      );
                      if (message == 'Success') {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => LoginPage(),
                          ),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(message as String),
                          ),
                        );
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          height: 1.0,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(width: 10),
                      const Text('Or'),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          height: 1.0,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      const Text('Already have an account?'),
                      const SizedBox(width: 10),
                      GestureDetector(
                        onTap: () {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => LoginPage(),
                              ));
                        },
                        child: const Text(
                          'Login',
                          style: TextStyle(
                            color: Colors.blue,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
