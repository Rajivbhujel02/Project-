import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:sports_zone/screens/home_screen.dart';
import 'package:sports_zone/screens/login_screen.dart';
import 'package:sports_zone/screens/profileScreen.dart';

enum MenuState { home, favourite, message, profile, create }

class CustomBottomNavBar extends StatelessWidget {
  const CustomBottomNavBar({
    Key? key,
    required this.selectedMenu,
  }) : super(key: key);

  final MenuState selectedMenu;

  @override
  Widget build(BuildContext context) {
    final Color inActiveIconColor = const Color(0xFFB6B6B6);
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            offset: const Offset(0, -15),
            blurRadius: 20,
            color: const Color(0xFFDADADA).withOpacity(0.15),
          ),
        ],
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(40),
          topRight: Radius.circular(40),
        ),
      ),
      child: SafeArea(
          top: false,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              IconButton(
                  icon: Icon(
                    Icons.storefront_outlined,
                    color: MenuState.home == selectedMenu
                        ? Colors.blue
                        : inActiveIconColor,
                    size: 30.0,
                  ),
                  onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(
                            builder: (context) => const HomeScreen()),
                      )),
              IconButton(
                  icon: Icon(
                    Icons.forum,
                    color: MenuState.create == selectedMenu
                        ? Colors.blue
                        : inActiveIconColor,
                    size: 30.0,
                  ),
                  onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => SelectScreen()),
                      )),
              /*IconButton(
                icon: Icon(Icons.textsms_outlined,
                  color: MenuState.message == selectedMenu
                    ? kPrimaryColor
                    : inActiveIconColor,),
                onPressed: () {},
              ),*/
              IconButton(
                  icon: Icon(
                    Icons.person_outline_rounded,
                    color: MenuState.profile == selectedMenu
                        ? Colors.blue
                        : inActiveIconColor,
                    size: 30.0,
                  ),
                  onPressed: () => Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (context) => ProfilePage()),
                      )),
            ],
          )),
    );
  }
}
