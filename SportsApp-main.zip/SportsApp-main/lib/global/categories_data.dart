List<String> categoriesImages = [
  'assets/images/football_badge.png',
  'assets/images/tennis_badge.png',
  'assets/images/basketball_badge.png',
  'assets/images/cricket_badge.png',
];
List<String> categoriesTitle = [
  'Football',
  'Tennis',
  'Basketball',
  'Cricket',
];

List<String> categoriesSub = [
  'cover all football leagues',
  'cover all tennis championships',
  'cover all basketball teams',
  'cover all cricket tournaments'
];
